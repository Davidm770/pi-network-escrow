let escrowData = [];

export default async function handler(req, res) {
  if (req.method === "POST") {
    const { buyer, seller, amount } = req.body;

    const newEscrow = {
      id: escrowData.length + 1,
      buyer,
      seller,
      amount,
      status: "Pending",
    };

    // Add to in-memory storage
    escrowData.push(newEscrow);

    // Simulate Pi Payment Request (replace with actual logic)
    console.log(`Initiating payment of ${amount} Pi from ${buyer} to escrow account`);

    res.status(201).json(newEscrow);
  } else if (req.method === "GET") {
    res.status(200).json(escrowData);
  } else {
    res.status(405).json({ message: "Method not allowed" });
  }
}